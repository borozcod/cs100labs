#include <iostream>
#include "./headers/op.hpp"
#include "./headers/sub.hpp"
#include "./headers/add.hpp"
#include "./headers/mult.hpp"
#include "./headers/container.hpp"
#include "./headers/ListContainer.hpp"
#include "./headers/sort.hpp"
#include "./headers/bubble_sort.hpp"

int main() {
    Op* seven = new Op(7);
    Op* four = new Op(4);
    Mult* TreeA = new Mult(seven, four);

    Op* three = new Op(3);
    Op* two = new Op(2);
    Add* TreeB = new Add(three, two);

    Op* ten = new Op(10);
    Op* six = new Op(6);
    Sub* TreeC = new Sub(ten, six);

    Container* container = new ListContainer();
    container->add_element(TreeA);
    container->add_element(TreeB);
    container->add_element(TreeC);

    Sort* bubble_sort = new BubbleSort();
    container->set_sort_function(bubble_sort);
    container->sort();

    std::cout << container->size() << std::endl;    

    return 0;
}
