#ifndef __SUB_TEST_HPP__
#define __SUB_TEST_HPP__

#include "gtest/gtest.h"

#include "../headers/op.hpp"
#include "../headers/sub.hpp"

TEST(SubTest, SubBase) {
    Op* value1 = new Op(3);
    Op* value2 = new Op(2);

    Sub* test = new Sub(value1, value2);

    EXPECT_EQ(test->evaluate(), 1);
    EXPECT_EQ(test->stringify(), "1");
}

TEST(SubTest, SubZero) {
    Op* value1 = new Op(2);
    Op* value2 = new Op(0);

    Sub* test = new Sub(value1, value2);

    EXPECT_EQ(test->evaluate(), 2);
    EXPECT_EQ(test->stringify(), "2");
}

TEST(SubTest, SubNegative) {
    Op* value1 = new Op(1);
    Op* value2 = new Op(-2);

    Sub* test = new Sub(value1, value2);

    EXPECT_EQ(test->evaluate(), 3);
    EXPECT_EQ(test->stringify(), "3");
}

TEST(SubTest, SubNegativeReturn) {
    Op* value1 = new Op(-2);
    Op* value2 = new Op(1);

    Sub* test = new Sub(value1, value2);

    EXPECT_EQ(test->evaluate(), -3);
    EXPECT_EQ(test->stringify(), "-3");
}


#endif //__SUB_TEST_HPP__
