#include <iostream>
#include <vector>
#include "container.hpp"
#include "ss.hpp"
#include "base.hpp"
#include "sort.hpp"
using namespace std;

class Sort;
class Container;

class VectorContainer : public Container
{
	private:
		vector<Base*> vector1;
		Base* child;
//		sort* sorter;
	public:
	//	VectorContainer(): child(NULL) {}
	//	VectorContainer(Sort* vectors): child(NULL)
	//	{
	//		sort_function = vectors;
	//	}
                void sort()
                {
  			this->sort_function->sort(this);
		}

		void add_element(Base* newElement)
		{
			vector1.push_back(newElement);
		}
		void print()
		{
			for(int i = 0; i < vector1.size(); ++i)
			{
				cout << vector1.at(i)->evaluate() << endl;
			}
		}


		void swap(int first, int second)
		{
			Base* Val  = vector1.at(first);
			vector1.at(first) = vector1.at(second);
			vector1.at(second) = Val;
		}

		Base* at(int i)
		{
			return vector1.at(i);
		}
		int size()
		{
			return vector1.size();
		}
};
