#ifndef _ABSOLUTE_HPP_
#define _ABSOLUTE_HPP_


#include <math.h>
#include <stdlib.h>
#include "decorator.hpp"
#include "op.hpp"


class Abs : public Decorator {
        private:
                Base* value;

        public:
                Abs(Base* value) : Decorator(value) {
                        this->value = value;
                }

                virtual double evaluate() { return abs(Decorator::evaluate()) ; }
                virtual std::string stringify() { return NULL; }
                };
               
#endif // _ABSOLUTE_HPP_
               
