#ifndef _FACTORY_HPP_
#define _FACTORY_HPP_

#include "base.hpp"
#include "op.hpp"
#include "add.hpp"
#include "sub.hpp"
#include "mult.hpp"
#include <iostream>
#include <string>
#include <stdlib.h>

class Factory {
        private:
            Base* root;

        public:
            Factory(int argc, char** argv) {
		
		this->root = new Op(atof(argv[1]));

		for(int i = 1; i < argc; i++) {
		    
		    Base* temp;

		    if(*argv[i] == '+') {
		        temp = new Add(this->root, new Op(atof(argv[i + 1])));
			this->root = temp;
		    } else if(*argv[i] == '-') { 
			temp = new Sub(this->root, new Op(atof(argv[i + 1])));
			this->root = temp;
		    } else if(*argv[i] == '*') { 
			temp = new Mult(this->root, new Op(atof(argv[i + 1])));
			this->root = temp;
		    }
		}
            }
	
	    double evaluate() {
		return root->evaluate();
	    }
};
               
#endif // _FACTORY_HPP_               
