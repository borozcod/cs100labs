#ifndef _PAREN_HPP_
#define _PAREN_HPP_


#include <math.h>
#include <stdlib.h>
#include "base.hpp"
#include "op.hpp"
#include "decorator.hpp"


class Paren : public Decorator {
     //   private:
     //           Base* value;

        public:
                Paren(Base* temp) : Decorator(temp) {
                //  Decorator(Base* value)
		//   this->value = value;
                }

                virtual double evaluate() { return Decorator::evaluate() ; }
                //virtual std::string stringify() { return "(" + std::to_string(value->evaluate() + " " + std::to_string(value->evaluate()) + " ) " ; }
                virtual std::string stringify() { return "(" +  Decorator::stringify() + ")"  ; }
                };

#endif // _PAREN_HPP_

