#ifndef __SS_HPP__
#define __SS_HPP__
#include <algorithm>
#include "container.hpp"
#include "sort.hpp"
class Container;
class Sort;

class SelectionSort : public Sort
{
	public:
		SelectionSort(): Sort() {}
		//SelectionSort(Container* temp): child(temp) {}
		void sort(Container* temp)
		{
			//child = temp;
			int first, in, out;
			for(out = temp->size() -1; out > 0; out--)
			{
				first = 0;
				for(in = 0; in <= out; ++in)
				{
					if(temp->at(in)->evaluate() > temp->at(first)->evaluate())
					{
						first = in;
					}
				}
				temp->swap(first, out);
			}
		}
};	

//void SelectionSort(vector1 <int> &num)
//{
 //     int i, j, first, temp;
//      int numLength = num.length( );
//      for (i= numLength - 1; i > 0; i--)
//     {
//           first = 0;                 // initialize to subscript of first element
//           for (j=1; j<=i; j++)   // locate smallest between positions 1 and i.
 //         {
 //                if (num[j] < num[first])
//                 first = j;
//          }
//         temp = num[first];   // Swap smallest found with element in position i.
//         num[first] = num[i];
//         num[i] = temp;
//     }
//     return;
//}



#endif //__SS_HPP__

