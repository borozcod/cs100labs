#ifndef __TRUNC_HPP__
#define __TRUNC_HPP__

#include <string>
#include "decorator.hpp"

class Trunc : public Decorator {

    public:
        /* Constructors */
        Trunc(Base* c) : Decorator(c) {

	};

        /* Virtual Functions */
        virtual double evaluate() {
	    return Decorator::evaluate();
	}

        virtual std::string stringify() {
	    return std::to_string( (int) Decorator::evaluate());
	};
};

#endif //__TRUNC_HPP__
