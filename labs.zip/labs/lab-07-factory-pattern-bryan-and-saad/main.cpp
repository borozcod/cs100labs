#include <iostream>
#include "./headers/factory.hpp"

int main(int argc, char** argv) 
{
    Factory* f = new Factory(argc, argv );
    std::cout <<  f->evaluate() << std::endl;
    return 0;
}


