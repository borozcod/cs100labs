#ifndef __ABSOLUTE_TEST_HPP__
#define __ABSOLUTE_TEST_HPP__

#include "gtest/gtest.h"

#include "../headers/op.hpp"
#include "../headers/absolute.hpp"

TEST(AbsoluteTest, AbsoluteValue) {
    Op* value1 = new Op(-1);
    Op* value2 = new Op(-2);

    Abs* test = new Abs(value1);
    Abs* test2 = new Abs(value2);

    EXPECT_EQ(test->evaluate(), 1);
    EXPECT_EQ(test2->evaluate(), 2);
}


#endif //__ABSOLUTE_TEST_HPP__
