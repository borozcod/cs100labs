#ifndef __ADD_ELEM_TEST_HPP__
#define __ADD_ELEM_TEST_HPP__

#include "gtest/gtest.h"

#include "../headers/op.hpp"
#include "../headers/VectorContainer.cpp"
 

TEST(VectorContainerTestSet, add_Elem_test) {
   //  Setup the elements under test
         Op* seven = new Op(7);
         Op* three = new Op(3);
	 Op* six   = new Op(6); 

	VectorContainer* test_container = new VectorContainer();
    
   // Exercise some functionality of hte test elements
          test_container->add_element(seven);
	  test_container->add_element(three);
	  test_container->add_element(six);
    
   // Assert that the container has at least a single element
   // otherwise we are likely to cause a segfault when accessing
          ASSERT_EQ(test_container->size(), 3);
          EXPECT_EQ(test_container->at(1)->evaluate(), 3);
  }

#endif //__ADD_ELEM_TEST_HPP__

