#ifndef __ADD_TEST_HPP__
#define __ADD_TEST_HPP__

#include "gtest/gtest.h"

#include "../headers/op.hpp"
#include "../headers/add.hpp"

TEST(AddTest, AddBase) {
    Op* value1 = new Op(1);
    Op* value2 = new Op(2);

    Add* test = new Add(value1, value2);

    EXPECT_EQ(test->evaluate(), 3);
}

TEST(AddTest, AddZero) {
    Op* value1 = new Op(0);
    Op* value2 = new Op(0);

    Add* test = new Add(value1, value2);

    EXPECT_EQ(test->evaluate(), 0);
}

TEST(AddTest, AddNegative) {
    Op* value1 = new Op(1);
    Op* value2 = new Op(-2);

    Add* test = new Add(value1, value2);

    EXPECT_EQ(test->evaluate(), -1);
}





#endif //__ADD_TEST_HPP__
