#ifndef __CEIL_TEST_HPP__
#define __CEIL_TEST_HPP__

#include "gtest/gtest.h"

#include "../headers/ceiling.hpp"
#include "../headers/op.hpp"

TEST(CeilTest, Round) {
    Op* value1 = new Op(1.1);
    Op* value2 = new Op(1.6);

    Ceil* test = new Ceil(value1);
    Ceil* test2 = new Ceil(value2);

    EXPECT_EQ(test->evaluate(), 2);
    EXPECT_EQ(test2->evaluate(), 2);
}


#endif //__CEIL_TEST_HPP__
