#ifndef __DIV_TEST_HPP__
#define __DIV_TEST_HPP__

#include "gtest/gtest.h"

#include "../headers/op.hpp"
#include "../headers/div.hpp"

TEST(DivTest, DivBase) {
    Op* value1 = new Op(2);
    Op* value2 = new Op(2);

    Div* test = new Div(value1, value2);

    EXPECT_EQ(test->evaluate(), 1);
}

TEST(DivTest, DivZero) {
    Op* value1 = new Op(0);
    Op* value2 = new Op(2);

    Div* test = new Div(value1, value2);

    EXPECT_EQ(test->evaluate(), 0);
}

TEST(DivTest, DivNegative) {
    Op* value1 = new Op(-3);
    Op* value2 = new Op(3);

    Div* test = new Div(value1, value2);

    EXPECT_EQ(test->evaluate(), -1);
}

#endif //__DIV_TEST_HPP__

