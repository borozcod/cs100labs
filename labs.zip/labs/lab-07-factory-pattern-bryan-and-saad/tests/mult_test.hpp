#ifndef __MULT_TEST_HPP__
#define __MULT_TEST_HPP__

#include "gtest/gtest.h"

#include "../headers/op.hpp"
#include "../headers/mult.hpp"

TEST(MultTest, MultBase) {
    Op* value1 = new Op(2);
    Op* value2 = new Op(2);

    Mult* test = new Mult(value1, value2);

    EXPECT_EQ(test->evaluate(), 4);
}

TEST(MultTest, MultZero) {
    Op* value1 = new Op(0);
    Op* value2 = new Op(2);

    Mult* test = new Mult(value1, value2);

    EXPECT_EQ(test->evaluate(), 0);
}

TEST(MultTest, MultNegative) {
    Op* value1 = new Op(1);
    Op* value2 = new Op(-2);

    Mult* test = new Mult(value1, value2);

    EXPECT_EQ(test->evaluate(), -2);
}





#endif //__MULT_TEST_HPP__
