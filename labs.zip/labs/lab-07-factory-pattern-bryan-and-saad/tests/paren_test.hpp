#ifndef __PAREN_TEST_HPP__
#define __PAREN_TEST_HPP__

#include "gtest/gtest.h"

#include "../headers/paren.hpp"
#include "../headers/op.hpp"
#include "../headers/add.hpp"

TEST(PARENTest, testingparen) {
    Op* value1 = new Op(2.0);
    Op* value2 = new Op(5.0);

    Add* add  = new Add(value1, value2);
    Paren* test2 = new Paren(add);

    EXPECT_EQ(test2->stringify(),"( 2 + 5 )");
}


#endif //__PAREN_TEST_HPP__

