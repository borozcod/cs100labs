#ifndef __SWAP_TEST_HPP__
#define __SWAP_TEST_HPP__

#include "gtest/gtest.h"

#include "../headers/op.hpp"
#include "../headers/VectorContainer.cpp"


TEST(VectorContainerTestSet, SwapTest) {
   //  Setup the elements under test
              Op* seven = new Op(7);
              Op* one = new Op(1);
              Op* four = new Op(4);
              VectorContainer* test_container = new VectorContainer();
   
    // Exercise some functionality of hte test elements
              test_container->add_element(seven);
              test_container->add_element(one);
              test_container->add_element(four);
   
     // Assert that the container has at least a single element
     // otherwise we are likely to cause a segfault when accessing
              ASSERT_EQ(test_container->size(), 3);
              EXPECT_EQ(test_container->at(0)->evaluate(), 7);
              EXPECT_EQ(test_container->at(1)->evaluate(), 1);
              EXPECT_EQ(test_container->at(2)->evaluate(), 4);
       	      test_container->swap(0,1);
              EXPECT_EQ(test_container->at(1)->evaluate(), 7);

 }
   
#endif //__SWAP_TEST_HPP__
                                                               
