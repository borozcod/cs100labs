#ifndef __TRUNC_TEST_HPP__
#define __TRUNC_TEST_HPP__

#include "gtest/gtest.h"

#include "../headers/op.hpp"
#include "../headers/add.hpp"
#include "../headers/trunc.hpp"

TEST(TruncTest, AddTestValue) {
    Op* value1 = new Op(1);
    Op* value2 = new Op(4);

    Add* add = new Add(value1, value2);
    Trunc* test = new Trunc(add);

    EXPECT_EQ(test->stringify(), "5");
}


#endif //__TRUNC_TEST_HPP__
